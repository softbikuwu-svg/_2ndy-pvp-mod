const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { Client, Authenticator } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const DATA = app.getPath('userData');
const ROOT = path.join(DATA, 'minecraft');
const TOOLS = path.join(DATA, 'tools');
const MOD_MC = '1.20.1'; // версия, под которую собран мод NanoCore
const UA = { 'User-Agent': 'NanoCore/1.0' };

let win;
let running = false;

const db = (file) => ({
  read() { try { return JSON.parse(fs.readFileSync(path.join(DATA, file), 'utf8')); } catch { return []; } },
  write(v) { fs.mkdirSync(DATA, { recursive: true }); fs.writeFileSync(path.join(DATA, file), JSON.stringify(v, null, 2)); },
});
const insts = db('instances.json');
const accs = db('accounts.json');

const send = (ch, m) => win && !win.isDestroyed() && win.webContents.send(ch, m);
const log = (m) => send('log', m);
const setState = (s) => send('state', s);

function h(channel, fn) {
  ipcMain.handle(channel, async (_, ...a) => {
    try { return { ok: true, data: await fn(...a) }; }
    catch (e) { return { ok: false, error: e.message || String(e) }; }
  });
}

async function download(url, dest) {
  const r = await fetch(url, { headers: UA });
  if (!r.ok) throw new Error(`Не удалось скачать ${url} (${r.status})`);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, Buffer.from(await r.arrayBuffer()));
}
const getJson = async (url) => {
  const r = await fetch(url, { headers: UA });
  if (!r.ok) throw new Error(`Ошибка запроса ${url} (${r.status})`);
  return r.json();
};
const run = (cmd, args) => new Promise((res, rej) => execFile(cmd, args, (e) => (e ? rej(e) : res())));

const instDir = (i) => path.join(DATA, 'instances', i.id);
const modsDir = (i) => path.join(instDir(i), 'mods');

// ---------- Java ----------
function findJava(dir) {
  if (!fs.existsSync(dir)) return null;
  for (const d of fs.readdirSync(dir)) {
    const p = path.join(dir, d, 'bin', 'java.exe');
    if (fs.existsSync(p)) return p;
  }
  return null;
}
async function ensureJava() {
  const local = path.join(TOOLS, 'java17');
  let exe = findJava(local);
  if (exe) return exe;
  log('Скачиваю Java 17 (один раз)...');
  fs.mkdirSync(local, { recursive: true });
  const zip = path.join(TOOLS, 'java17.zip');
  await download('https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jre/hotspot/normal/eclipse', zip);
  await run('tar', ['-xf', zip, '-C', local]);
  fs.unlinkSync(zip);
  exe = findJava(local);
  if (!exe) throw new Error('Не удалось установить Java');
  return exe;
}

// ---------- Fabric ----------
async function ensureFabric(mc) {
  const list = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${mc}`);
  if (!list.length) throw new Error(`Fabric недоступен для ${mc}`);
  const loader = (list.find((x) => x.loader.stable) || list[0]).loader.version;
  const profile = await getJson(`https://meta.fabricmc.net/v2/versions/loader/${mc}/${loader}/profile/json`);
  const dir = path.join(ROOT, 'versions', profile.id);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, `${profile.id}.json`), JSON.stringify(profile));
  return profile.id;
}

// ---------- Моды (Modrinth) ----------
async function installMod(inst, slug) {
  const url = `https://api.modrinth.com/v2/project/${encodeURIComponent(slug)}/version` +
    `?game_versions=${encodeURIComponent(JSON.stringify([inst.mc]))}&loaders=${encodeURIComponent('["fabric"]')}`;
  const r = await fetch(url, { headers: UA });
  if (!r.ok) throw new Error(`Мод "${slug}" не найден на Modrinth`);
  const versions = await r.json();
  if (!versions.length) throw new Error(`У мода "${slug}" нет версии для ${inst.mc}`);
  const f = versions[0].files.find((x) => x.primary) || versions[0].files[0];
  await download(f.url, path.join(modsDir(inst), f.filename));
  return f.filename;
}
function copyNanoMod(inst) {
  const src = path.join(app.isPackaged ? process.resourcesPath : __dirname, 'resources', 'nanocore-mod.jar');
  if (!fs.existsSync(src)) { log('Мод NanoCore не найден в сборке лаунчера, пропускаю.'); return; }
  fs.mkdirSync(modsDir(inst), { recursive: true });
  fs.copyFileSync(src, path.join(modsDir(inst), 'nanocore-mod.jar'));
}

// ---------- Аккаунты ----------
async function ensureInjector() {
  const f = path.join(TOOLS, 'authlib-injector.jar');
  if (fs.existsSync(f)) return f;
  const meta = await getJson('https://authlib-injector.yushi.moe/artifact/latest.json');
  await download(meta.download_url, f);
  return f;
}
async function resolveAuth(acc, list) {
  if (acc.type === 'microsoft') {
    const am = new Auth('select_account');
    const xbox = await am.refresh(acc.refresh);
    const t = await xbox.getMinecraft();
    acc.refresh = xbox.save();
    accs.write(list);
    return { auth: t.mclc(), args: [] };
  }
  if (acc.type === 'ely') {
    const r = await fetch('https://authserver.ely.by/auth/refresh', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ accessToken: acc.accessToken, clientToken: acc.clientToken }),
    });
    if (!r.ok) throw new Error('Сессия Ely.by истекла. Удали аккаунт и добавь заново.');
    const d = await r.json();
    acc.accessToken = d.accessToken;
    accs.write(list);
    const jar = await ensureInjector();
    return {
      auth: { access_token: d.accessToken, client_token: acc.clientToken, uuid: acc.uuid, name: acc.name, user_properties: '{}', meta: { type: 'mojang', demo: false } },
      args: [`-javaagent:${jar}=ely.by`],
    };
  }
  return { auth: Authenticator.getAuth(acc.name), args: [] };
}

h('acc:list', () => accs.read().map(({ id, type, name }) => ({ id, type, name })));
h('acc:remove', (id) => { accs.write(accs.read().filter((a) => a.id !== id)); });
h('acc:offline', (name) => {
  if (!/^\w{3,16}$/.test(name || '')) throw new Error('Ник: 3-16 символов, латиница, цифры, _');
  const l = accs.read(); l.push({ id: crypto.randomUUID(), type: 'offline', name }); accs.write(l);
});
h('acc:ms', async () => {
  const am = new Auth('select_account');
  const xbox = await am.launch('electron');
  const t = await xbox.getMinecraft();
  const l = accs.read().filter((a) => !(a.type === 'microsoft' && a.name === t.profile.name));
  l.push({ id: crypto.randomUUID(), type: 'microsoft', name: t.profile.name, refresh: xbox.save() });
  accs.write(l);
});
h('acc:ely', async ({ login, password }) => {
  const clientToken = crypto.randomUUID().replace(/-/g, '');
  const r = await fetch('https://authserver.ely.by/auth/authenticate', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: login, password, clientToken, requestUser: true }),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (/two.?factor/i.test(d.errorMessage || '')) throw new Error('Включена 2FA: впиши пароль и код через двоеточие, например пароль:123456');
    throw new Error(d.errorMessage || 'Не удалось войти в Ely.by');
  }
  const p = d.selectedProfile;
  const l = accs.read().filter((a) => !(a.type === 'ely' && a.uuid === p.id));
  l.push({ id: crypto.randomUUID(), type: 'ely', name: p.name, uuid: p.id, accessToken: d.accessToken, clientToken });
  accs.write(l);
});

// ---------- Сборки ----------
h('versions', async () => {
  const m = await getJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json');
  return m.versions.filter((v) => v.type === 'release').map((v) => v.id);
});
h('inst:list', () => insts.read());
h('inst:open', (id) => {
  const i = insts.read().find((x) => x.id === id);
  fs.mkdirSync(instDir(i), { recursive: true });
  shell.openPath(instDir(i));
});
h('inst:delete', (id) => {
  const i = insts.read().find((x) => x.id === id);
  insts.write(insts.read().filter((x) => x.id !== id));
  if (i) fs.rmSync(instDir(i), { recursive: true, force: true });
});
h('inst:addMod', async ({ id, slug }) => {
  const i = insts.read().find((x) => x.id === id);
  if (i.loader !== 'fabric') throw new Error('Моды можно ставить только в сборки с Fabric');
  return installMod(i, slug.trim());
});
h('inst:create', async ({ name, mc, loader, ram, essential }) => {
  if (!name || !name.trim()) throw new Error('Введи название сборки');
  const inst = { id: crypto.randomUUID().slice(0, 8), name: name.trim(), mc, loader, ram: Number(ram) || 4 };
  fs.mkdirSync(inst.loader === 'fabric' ? modsDir(inst) : instDir(inst), { recursive: true });
  const warnings = [];
  if (loader === 'fabric') {
    try { await installMod(inst, 'fabric-api'); } catch (e) { warnings.push(e.message); }
    if (essential) { try { await installMod(inst, 'essential'); } catch (e) { warnings.push('Essential: ' + e.message); } }
  }
  const l = insts.read(); l.push(inst); insts.write(l);
  return warnings;
});

// ---------- Запуск ----------
h('launch', async ({ instanceId, accountId }) => {
  if (running) throw new Error('Игра уже запущена');
  const inst = insts.read().find((i) => i.id === instanceId);
  const list = accs.read();
  const acc = list.find((a) => a.id === accountId);
  if (!inst) throw new Error('Сначала создай сборку');
  if (!acc) throw new Error('Сначала добавь аккаунт');
  running = true;
  try {
    setState('busy');
    const javaPath = await ensureJava();
    log('Вхожу в аккаунт...');
    const { auth, args } = await resolveAuth(acc, list);
    let custom;
    if (inst.loader === 'fabric') {
      custom = await ensureFabric(inst.mc);
      if (inst.mc === MOD_MC) copyNanoMod(inst);
    }
    const launcher = new Client();
    launcher.on('debug', (m) => log(m));
    launcher.on('data', (m) => log(String(m).trimEnd()));
    launcher.on('progress', (p) => send('progress', p));
    launcher.on('close', () => { running = false; setState('idle'); log('Игра закрыта.'); });
    const proc = await launcher.launch({
      authorization: auth,
      root: ROOT,
      javaPath,
      version: { number: inst.mc, type: 'release', ...(custom ? { custom } : {}) },
      memory: { max: `${inst.ram}G`, min: '1G' },
      overrides: { gameDirectory: instDir(inst) },
      customArgs: args,
    });
    if (!proc) throw new Error('Игра не запустилась, смотри лог');
    setState('playing');
  } catch (e) {
    running = false; setState('idle');
    throw e;
  }
});

app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 1100, height: 700, minWidth: 900, minHeight: 600,
    backgroundColor: '#0B1020', autoHideMenuBar: true, title: 'NanoCore',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
});
app.on('window-all-closed', () => app.quit());
