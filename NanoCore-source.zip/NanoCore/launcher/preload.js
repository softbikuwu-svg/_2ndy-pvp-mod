const { contextBridge, ipcRenderer } = require('electron');
const call = (c) => (...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('nano', {
  versions: call('versions'),
  listInstances: call('inst:list'),
  createInstance: call('inst:create'),
  deleteInstance: call('inst:delete'),
  addMod: call('inst:addMod'),
  openFolder: call('inst:open'),
  listAccounts: call('acc:list'),
  addMicrosoft: call('acc:ms'),
  addEly: call('acc:ely'),
  addOffline: call('acc:offline'),
  removeAccount: call('acc:remove'),
  launch: call('launch'),
  onLog: (cb) => ipcRenderer.on('log', (_, m) => cb(m)),
  onProgress: (cb) => ipcRenderer.on('progress', (_, p) => cb(p)),
  onState: (cb) => ipcRenderer.on('state', (_, s) => cb(s)),
});
