const $ = (s) => document.querySelector(s);
const api = async (f, ...a) => { const r = await window.nano[f](...a); if (!r.ok) throw new Error(r.error); return r.data; };
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const TYPE = { microsoft: 'Microsoft', ely: 'Ely.by', offline: 'Без лицензии' };
let S = { inst: [], acc: [] };

function toast(msg, bad) {
  const t = $('#toast'); t.textContent = msg; t.className = 'show' + (bad ? ' bad' : '');
  clearTimeout(toast.t); toast.t = setTimeout(() => (t.className = ''), 5000);
}
const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

function show(v) {
  document.querySelectorAll('.view').forEach((x) => (x.hidden = x.id !== 'v-' + v));
  document.querySelectorAll('nav button').forEach((b) => b.classList.toggle('on', b.dataset.v === v));
}
document.querySelectorAll('nav button').forEach((b) => (b.onclick = () => show(b.dataset.v)));

async function load() { S.inst = await api('listInstances'); S.acc = await api('listAccounts'); draw(); }

function fill(sel, items, label) {
  const old = sel.value;
  sel.innerHTML = items.length ? items.map((x) => `<option value="${x.id}">${esc(label(x))}</option>`).join('') : '<option value="">пусто</option>';
  if (items.some((x) => x.id === old)) sel.value = old;
}
function draw() {
  fill($('#selInst'), S.inst, (i) => `${i.name} (${i.mc}, ${i.loader})`);
  fill($('#selAcc'), S.acc, (a) => `${a.name} (${TYPE[a.type]})`);
  $('#instList').innerHTML = S.inst.length ? '' : '<p class="empty">Сборок пока нет. Создай первую ниже.</p>';
  S.inst.forEach((i) => {
    const d = document.createElement('div'); d.className = 'item';
    d.innerHTML = `<b>${esc(i.name)} <small>${i.mc} · ${i.loader} · ${i.ram} ГБ</small></b>` +
      (i.loader === 'fabric' ? `<input placeholder="мод на Modrinth" data-slug><button data-add>Добавить мод</button>` : '') +
      `<button data-open>Папка</button><button data-del>Удалить</button>`;
    d.querySelector('[data-open]').onclick = () => api('openFolder', i.id);
    d.querySelector('[data-del]').onclick = guard(async () => { await api('deleteInstance', i.id); await load(); });
    const add = d.querySelector('[data-add]');
    if (add) add.onclick = guard(async () => {
      const slug = d.querySelector('[data-slug]').value; if (!slug) return;
      toast('Скачиваю ' + slug + '...'); const f = await api('addMod', { id: i.id, slug }); toast('Установлено: ' + f);
    });
    $('#instList').appendChild(d);
  });
  $('#accList').innerHTML = S.acc.length ? '' : '<p class="empty">Аккаунтов пока нет. Добавь любой из вариантов ниже.</p>';
  S.acc.forEach((a) => {
    const d = document.createElement('div'); d.className = 'item';
    d.innerHTML = `<b>${esc(a.name)} <small>${TYPE[a.type]}</small></b><button>Удалить</button>`;
    d.querySelector('button').onclick = guard(async () => { await api('removeAccount', a.id); await load(); });
    $('#accList').appendChild(d);
  });
}

$('#iCreate').onclick = guard(async () => {
  const b = $('#iCreate'); b.disabled = true; toast('Создаю сборку, скачиваю моды...');
  try {
    const w = await api('createInstance', { name: $('#iName').value, mc: $('#iVer').value, loader: $('#iLoader').value, ram: $('#iRam').value, essential: $('#iEss').checked });
    await load(); $('#iName').value = '';
    toast(w.length ? 'Сборка создана. Замечания: ' + w.join('; ') : 'Сборка создана');
  } finally { b.disabled = false; }
});
$('#aMs').onclick = guard(async () => { await api('addMicrosoft'); await load(); toast('Аккаунт Microsoft добавлен'); });
$('#aEly').onclick = guard(async () => { await api('addEly', { login: $('#eLogin').value, password: $('#ePass').value }); $('#ePass').value = ''; await load(); toast('Аккаунт Ely.by добавлен'); });
$('#aOff').onclick = guard(async () => { await api('addOffline', $('#oName').value); $('#oName').value = ''; await load(); });

$('#play').onclick = guard(async () => {
  $('#log').textContent = '';
  await api('launch', { instanceId: $('#selInst').value, accountId: $('#selAcc').value });
});
window.nano.onLog((m) => { const l = $('#log'); l.textContent += m + '\n'; l.scrollTop = l.scrollHeight; });
window.nano.onProgress((p) => { if (p.total) $('#bar').style.width = Math.min(100, (p.task / p.total) * 100) + '%'; });
window.nano.onState((s) => {
  const b = $('#play'); b.disabled = s !== 'idle';
  b.textContent = s === 'idle' ? 'Играть' : s === 'busy' ? 'Подготовка...' : 'Игра запущена';
  if (s !== 'busy') $('#bar').style.width = '0';
});

(async () => {
  await load();
  try { const v = await api('versions'); $('#iVer').innerHTML = v.map((x) => `<option>${x}</option>`).join(''); $('#iVer').value = '1.20.1'; }
  catch { $('#iVer').innerHTML = '<option>1.20.1</option>'; }
})();
