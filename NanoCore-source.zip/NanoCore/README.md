# NanoCore + _2ndy's pvp

- `launcher/` — лаунчер NanoCore (Electron): сборки, Fabric, аккаунты Microsoft / Ely.by / без лицензии.
- `mod/` — мод _2ndy's pvp (Fabric 1.20.1): правый Shift — меню (вкладки «Моды» и «Визуалы»), G — эмоции, C — зум.
- `.github/workflows/build.yml` — собирает мод и лаунчер в .exe автоматически.

Выложи папку на GitHub (публичный репозиторий) и создай релиз с тегом `v1.0.0`.
