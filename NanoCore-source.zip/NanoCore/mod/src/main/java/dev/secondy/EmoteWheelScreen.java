package dev.secondy;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class EmoteWheelScreen extends Screen {
    public EmoteWheelScreen() { super(Text.literal("Эмоции")); }

    @Override
    protected void init() {
        int n = Emotes.NAMES.length, radius = 75, w = 76, h = 22;
        for (int i = 0; i < n; i++) {
            double a = -Math.PI / 2 + i * 2 * Math.PI / n;
            int x = (int) (width / 2 + Math.cos(a) * radius * 1.35) - w / 2;
            int y = (int) (height / 2 + Math.sin(a) * radius) - h / 2;
            final int id = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(Emotes.NAMES[i]), b -> { close(); Emotes.play(id); })
                    .dimensions(x, y, w, h).build());
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_G) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.drawCenteredTextWithShadow(textRenderer, "Эмоции", width / 2, height / 2 - 4, 0x6FD4FF);
        super.render(ctx, mouseX, mouseY, delta);
    }
}
