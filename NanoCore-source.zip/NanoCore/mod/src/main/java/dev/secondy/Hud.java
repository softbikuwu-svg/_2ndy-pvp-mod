package dev.secondy;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.item.ItemStack;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Deque;

public class Hud {
    private static final Deque<Long> LEFT = new ArrayDeque<>();
    private static final Deque<Long> RIGHT = new ArrayDeque<>();
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    private static boolean lastAttack, lastUse;
    private static int lastHurt;
    private static int combo;
    private static double reach;
    private static long reachTime;
    public static boolean zooming;

    public static void onAttack(double dist) {
        combo++;
        reach = dist;
        reachTime = System.currentTimeMillis();
    }

    public static void tick(MinecraftClient c) {
        long now = System.currentTimeMillis();
        boolean a = c.options.attackKey.isPressed();
        boolean u = c.options.useKey.isPressed();
        if (a && !lastAttack) LEFT.add(now);
        if (u && !lastUse) RIGHT.add(now);
        lastAttack = a;
        lastUse = u;
        prune(LEFT, now);
        prune(RIGHT, now);

        zooming = Config.mod("Zoom") && c.currentScreen == null && SecondyClient.zoomKey.isPressed();

        if (c.player == null) return;
        if (c.player.hurtTime > lastHurt) combo = 0;
        lastHurt = c.player.hurtTime;

        if (Config.mod("Toggle Sprint") && c.currentScreen == null
                && c.options.forwardKey.isPressed() && !c.player.isSneaking()
                && c.player.getHungerManager().getFoodLevel() > 6) {
            c.player.setSprinting(true);
        }
    }

    private static void prune(Deque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
    }

    public static void render(DrawContext ctx, float tickDelta) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        Visuals.crosshair(ctx, c);
        TextRenderer tr = c.textRenderer;
        int y = 6;
        if (Config.mod("FPS")) y = line(ctx, tr, "FPS: " + c.getCurrentFps(), y);
        if (Config.mod("CPS")) y = line(ctx, tr, "CPS: " + LEFT.size() + " | " + RIGHT.size(), y);
        if (Config.mod("Ping")) {
            PlayerListEntry e = c.getNetworkHandler() == null ? null : c.getNetworkHandler().getPlayerListEntry(c.player.getUuid());
            y = line(ctx, tr, "Ping: " + (e == null ? "-" : e.getLatency()) + " мс", y);
        }
        if (Config.mod("Coordinates")) {
            y = line(ctx, tr, String.format("XYZ: %.0f %.0f %.0f", c.player.getX(), c.player.getY(), c.player.getZ()), y);
        }
        if (Config.mod("Direction")) {
            String d = switch (c.player.getHorizontalFacing()) {
                case NORTH -> "N (-Z)"; case SOUTH -> "S (+Z)"; case EAST -> "E (+X)"; default -> "W (-X)";
            };
            y = line(ctx, tr, "Куда: " + d, y);
        }
        if (Config.mod("Clock")) y = line(ctx, tr, LocalTime.now().format(CLOCK), y);
        if (Config.mod("Memory")) {
            Runtime r = Runtime.getRuntime();
            y = line(ctx, tr, "RAM: " + (r.totalMemory() - r.freeMemory()) / 1048576 + " МБ", y);
        }
        if (Config.mod("Combo")) y = line(ctx, tr, "Combo: " + combo, y);
        if (Config.mod("Reach") && System.currentTimeMillis() - reachTime < 4000) {
            y = line(ctx, tr, String.format("Reach: %.2f", reach), y);
        }
        if (Config.mod("Keystrokes")) keystrokes(ctx, c, tr);
        if (Config.mod("Armor HUD")) armor(ctx, c, tr);
        if (Config.mod("Potions")) potions(ctx, c, tr);
    }

    private static int line(DrawContext ctx, TextRenderer tr, String s, int y) {
        ctx.drawTextWithShadow(tr, s, 6, y, 0xFFFFFF);
        return y + 11;
    }

    private static void key(DrawContext ctx, TextRenderer tr, KeyBinding k, String label, int x, int y, int w) {
        boolean down = k.isPressed();
        ctx.fill(x, y, x + w, y + 20, down ? 0xCC6FD4FF : 0x88000000);
        ctx.drawCenteredTextWithShadow(tr, label, x + w / 2, y + 6, down ? 0x06223A : 0xFFFFFF);
    }

    private static void keystrokes(DrawContext ctx, MinecraftClient c, TextRenderer tr) {
        int x = 10, y = c.getWindow().getScaledHeight() - 90;
        key(ctx, tr, c.options.forwardKey, "W", x + 22, y, 20);
        key(ctx, tr, c.options.leftKey, "A", x, y + 22, 20);
        key(ctx, tr, c.options.backKey, "S", x + 22, y + 22, 20);
        key(ctx, tr, c.options.rightKey, "D", x + 44, y + 22, 20);
        key(ctx, tr, c.options.attackKey, "ЛКМ", x, y + 44, 31);
        key(ctx, tr, c.options.useKey, "ПКМ", x + 33, y + 44, 31);
    }

    private static void armor(DrawContext ctx, MinecraftClient c, TextRenderer tr) {
        int x = c.getWindow().getScaledWidth() - 24;
        int y = c.getWindow().getScaledHeight() / 2 - 40;
        for (int i = 3; i >= 0; i--) {
            ItemStack s = c.player.getInventory().armor.get(i);
            if (s.isEmpty()) continue;
            ctx.drawItem(s, x, y);
            ctx.drawItemInSlot(tr, s, x, y);
            y += 18;
        }
    }

    private static void potions(DrawContext ctx, MinecraftClient c, TextRenderer tr) {
        int y = 6;
        int right = c.getWindow().getScaledWidth() - 6;
        for (StatusEffectInstance e : c.player.getStatusEffects()) {
            String s = e.getEffectType().getName().getString() + " " + (e.getAmplifier() + 1)
                    + " " + StatusEffectUtil.getDurationText(e, 1.0f).getString();
            ctx.drawTextWithShadow(tr, s, right - tr.getWidth(s), y, 0xFFFFFF);
            y += 11;
        }
    }
}
