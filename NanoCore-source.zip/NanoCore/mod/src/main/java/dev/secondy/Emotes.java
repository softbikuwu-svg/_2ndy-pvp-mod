package dev.secondy;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;

/** Простые эмоции: только визуальные действия на стороне клиента. */
public class Emotes {
    public static final String[] NAMES = {"Привет", "Танец", "Вертушка", "Поклон", "Хлопки", "Прыжок", "Осмотр", "Смех"};
    private static int current = -1, ticks = 0;
    private static float startYaw;

    public static void play(int id) { stop(); current = id; ticks = 0; }

    private static void stop() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.options != null) c.options.sneakKey.setPressed(false);
        current = -1;
    }

    public static void tick(MinecraftClient c) {
        if (current < 0) return;
        if (c.player == null) { current = -1; return; }
        int t = ticks++;
        switch (current) {
            case 0 -> { if (t % 6 == 0) c.player.swingHand(Hand.MAIN_HAND); if (t >= 36) stop(); }
            case 1 -> { c.options.sneakKey.setPressed((t / 5) % 2 == 0); if (t % 10 == 0) c.player.swingHand(Hand.MAIN_HAND); if (t >= 80) stop(); }
            case 2 -> { c.player.setYaw(c.player.getYaw() + 18); if (t >= 20) stop(); }
            case 3 -> { c.options.sneakKey.setPressed(t < 14); if (t >= 18) stop(); }
            case 4 -> { if (t % 4 == 0) c.player.swingHand(t % 8 == 0 ? Hand.MAIN_HAND : Hand.OFF_HAND); if (t >= 40) stop(); }
            case 5 -> { if (c.player.isOnGround() && t % 12 == 0) c.player.jump(); if (t >= 24) stop(); }
            case 6 -> {
                if (t == 0) startYaw = c.player.getYaw();
                c.player.setYaw(startYaw + (float) Math.sin(t / 5.0) * 45f);
                if (t >= 40) { c.player.setYaw(startYaw); stop(); }
            }
            case 7 -> { c.options.sneakKey.setPressed((t / 2) % 2 == 0); if (t >= 24) stop(); }
            default -> stop();
        }
    }
}
