package dev.secondy.mixin;

import dev.secondy.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public class FireMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"))
    private static void secondy$lowFireStart(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        if (Config.visual("Low fire")) { matrices.push(); matrices.translate(0, -0.3, 0); }
    }

    @Inject(method = "renderFireOverlay", at = @At("RETURN"))
    private static void secondy$lowFireEnd(MinecraftClient client, MatrixStack matrices, CallbackInfo ci) {
        if (Config.visual("Low fire")) matrices.pop();
    }
}
