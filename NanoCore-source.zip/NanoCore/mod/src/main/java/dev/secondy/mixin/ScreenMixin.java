package dev.secondy.mixin;

import dev.secondy.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public class ScreenMixin {
    @Inject(method = "renderBackground(Lnet/minecraft/client/gui/DrawContext;)V", at = @At("HEAD"), cancellable = true)
    private void secondy$darkGui(DrawContext ctx, CallbackInfo ci) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (Config.visual("Dark GUI") && c.world != null) {
            ctx.fill(0, 0, c.getWindow().getScaledWidth(), c.getWindow().getScaledHeight(), 0x66000000);
            ci.cancel();
        }
    }
}
