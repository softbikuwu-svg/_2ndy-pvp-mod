package dev.secondy;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class SecondyClient implements ClientModInitializer {
    public static KeyBinding menuKey, emoteKey, zoomKey;

    private static KeyBinding bind(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.secondypvp." + name, InputUtil.Type.KEYSYM, key, "category.secondypvp"));
    }

    @Override
    public void onInitializeClient() {
        Config.load();
        menuKey = bind("menu", GLFW.GLFW_KEY_RIGHT_SHIFT);
        emoteKey = bind("emotes", GLFW.GLFW_KEY_G);
        zoomKey = bind("zoom", GLFW.GLFW_KEY_C);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient) Hud.onAttack(player.distanceTo(entity));
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) client.setScreen(new ModMenuScreen());
            while (emoteKey.wasPressed()) {
                if (client.player != null) client.setScreen(new EmoteWheelScreen());
            }
            Hud.tick(client);
            Visuals.tick(client);
            Emotes.tick(client);
        });
        HudRenderCallback.EVENT.register(Hud::render);
    }
}
