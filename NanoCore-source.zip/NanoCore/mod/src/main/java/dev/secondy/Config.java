package dev.secondy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public class Config {
    public static final String[] MODS = {
            "FPS", "CPS", "Ping", "Keystrokes", "Coordinates", "Direction", "Armor HUD",
            "Potions", "Clock", "Memory", "Combo", "Reach", "Toggle Sprint", "Zoom"
    };
    public static final String[] VISUALS = {
            "Low fire", "Custom crosshair", "Dark GUI", "No hurt cam", "Time changer", "Clear weather"
    };

    public static class Data {
        public Map<String, Boolean> modules = new LinkedHashMap<>();
        public Map<String, Boolean> visuals = new LinkedHashMap<>();
        public Map<String, Double> values = new LinkedHashMap<>();
    }

    private static Data d = new Data();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    static {
        for (String m : MODS) d.modules.put(m, m.equals("FPS") || m.equals("CPS") || m.equals("Keystrokes") || m.equals("Armor HUD"));
        for (String v : VISUALS) d.visuals.put(v, false);
        d.values.put("Time", 6000.0);
        d.values.put("Zoom", 4.0);
        d.values.put("Crosshair", 1.0);
    }

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("secondypvp.json"); }

    public static boolean mod(String k) { return d.modules.getOrDefault(k, false); }
    public static boolean visual(String k) { return d.visuals.getOrDefault(k, false); }
    public static double value(String k) { return d.values.getOrDefault(k, 0.0); }
    public static void setValue(String k, double v) { d.values.put(k, v); save(); }
    public static void toggleMod(String k) { d.modules.put(k, !mod(k)); save(); }
    public static void toggleVisual(String k) { d.visuals.put(k, !visual(k)); save(); }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Data x = GSON.fromJson(Files.readString(file()), Data.class);
            if (x == null) return;
            if (x.modules != null) x.modules.forEach((k, v) -> { if (d.modules.containsKey(k)) d.modules.put(k, v); });
            if (x.visuals != null) x.visuals.forEach((k, v) -> { if (d.visuals.containsKey(k)) d.visuals.put(k, v); });
            if (x.values != null) x.values.forEach((k, v) -> { if (d.values.containsKey(k)) d.values.put(k, v); });
        } catch (Exception ignored) {}
    }

    public static void save() {
        try { Files.writeString(file(), GSON.toJson(d)); } catch (Exception ignored) {}
    }
}
