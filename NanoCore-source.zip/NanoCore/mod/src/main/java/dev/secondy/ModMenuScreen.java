package dev.secondy;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ModMenuScreen extends Screen {
    private static int tab = 0; // 0 = моды, 1 = визуалы
    private static final String[] CROSS = {"Точка", "Малый крест", "Крест"};

    public ModMenuScreen() {
        super(Text.literal("_2ndy's pvp"));
    }

    private static Text onOff(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
    }

    private static class ValueSlider extends SliderWidget {
        private final String key, label;
        private final double min, max;
        ValueSlider(int x, int y, int w, int h, String label, String key, double min, double max) {
            super(x, y, w, h, Text.empty(), (Config.value(key) - min) / (max - min));
            this.key = key; this.label = label; this.min = min; this.max = max;
            updateMessage();
        }
        private double real() { return min + value * (max - min); }
        @Override protected void updateMessage() { setMessage(Text.literal(label + ": " + Math.round(real() * 10) / 10.0)); }
        @Override protected void applyValue() { Config.setValue(key, real()); }
    }

    @Override
    protected void init() {
        int top = 28;
        addDrawableChild(ButtonWidget.builder(Text.literal(tab == 0 ? "[ Моды ]" : "Моды"), b -> { tab = 0; clearAndInit(); })
                .dimensions(width / 2 - 105, top, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(tab == 1 ? "[ Визуалы ]" : "Визуалы"), b -> { tab = 1; clearAndInit(); })
                .dimensions(width / 2 + 5, top, 100, 20).build());

        int w = 104, h = 20, gap = 4, cols = 3;
        int startX = width / 2 - (cols * w + (cols - 1) * gap) / 2;
        int y0 = top + 30;
        String[] names = tab == 0 ? Config.MODS : Config.VISUALS;
        for (int i = 0; i < names.length; i++) {
            final String n = names[i];
            int x = startX + (i % cols) * (w + gap);
            int y = y0 + (i / cols) * (h + gap);
            addDrawableChild(ButtonWidget.builder(onOff(n, tab == 0 ? Config.mod(n) : Config.visual(n)), b -> {
                if (tab == 0) Config.toggleMod(n); else Config.toggleVisual(n);
                b.setMessage(onOff(n, tab == 0 ? Config.mod(n) : Config.visual(n)));
            }).dimensions(x, y, w, h).build());
        }
        int rows = (names.length + cols - 1) / cols;
        int y = y0 + rows * (h + gap) + 6;
        int full = cols * w + (cols - 1) * gap;
        if (tab == 1) {
            addDrawableChild(new ValueSlider(startX, y, full, h, "Время суток", "Time", 0, 24000));
            addDrawableChild(new ValueSlider(startX, y + h + gap, full, h, "Сила зума (клавиша C)", "Zoom", 1.5, 8));
            addDrawableChild(ButtonWidget.builder(Text.literal("Прицел: " + CROSS[(int) Config.value("Crosshair")]), b -> {
                Config.setValue("Crosshair", (Config.value("Crosshair") + 1) % CROSS.length);
                b.setMessage(Text.literal("Прицел: " + CROSS[(int) Config.value("Crosshair")]));
            }).dimensions(startX, y + 2 * (h + gap), full, h).build());
            y += 3 * (h + gap);
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                .dimensions(width / 2 - 50, y + 4, 100, 20).build());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(textRenderer, "_2ndy's pvp", width / 2, 12, 0x6FD4FF);
        super.render(ctx, mouseX, mouseY, delta);
    }
}
