package dev.secondy;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Косметические визуалы. Ничего, что даёт преимущество (ESP, X-ray, fullbright и т.п.). */
public class Visuals {
    public static void tick(MinecraftClient c) {
        if (c.world == null) return;
        if (Config.visual("Time changer")) c.world.setTimeOfDay((long) Config.value("Time"));
        if (Config.visual("Clear weather")) {
            c.world.setRainGradient(0f);
            c.world.setThunderGradient(0f);
        }
    }

    public static void crosshair(DrawContext ctx, MinecraftClient c) {
        if (!Config.visual("Custom crosshair") || c.currentScreen != null || c.options.hudHidden) return;
        if (!c.options.getPerspective().isFirstPerson()) return;
        int cx = c.getWindow().getScaledWidth() / 2;
        int cy = c.getWindow().getScaledHeight() / 2;
        int col = 0xFFFFFFFF;
        switch ((int) Config.value("Crosshair")) {
            case 0 -> ctx.fill(cx - 1, cy - 1, cx + 1, cy + 1, col);
            case 1 -> {
                ctx.fill(cx - 5, cy, cx - 2, cy + 1, col);
                ctx.fill(cx + 2, cy, cx + 5, cy + 1, col);
                ctx.fill(cx, cy - 5, cx + 1, cy - 2, col);
                ctx.fill(cx, cy + 2, cx + 1, cy + 5, col);
            }
            default -> {
                ctx.fill(cx - 7, cy, cx + 8, cy + 1, col);
                ctx.fill(cx, cy - 7, cx + 1, cy + 8, col);
            }
        }
    }
}
